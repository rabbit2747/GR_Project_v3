---
name: "Rule Proposal"
about: Rule Idea Proposal
title: ''
labels: Rule
assignees:
  - nasbench

---

### Description of the Idea of the Rule

<!--
A clear and concise description of idea of the rule.
-->

### Public References / Example Event Log

<!--
Additional references and logs if possible to ease the process of creating the rule
-->
