# Deprecated folder

This folder contains all rules that have been marked as deprecated.

It is recommended to avoid using these rules, as they are no longer maintained or supported.

For a summary of the deprecated rules, refer to [deprecated.csv](./deprecated.csv) or [deprecated.json](./deprecated.json)


# references

https://github.com/SigmaHQ/sigma-specification/blob/main/specification/sigma-rules-specification.md#status